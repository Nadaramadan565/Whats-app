package com.example.whatsapp;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

public class SectionPagerAdapter extends FragmentPagerAdapter {


    public SectionPagerAdapter(FragmentManager fm) {
        super(fm);
    }

    @NonNull
    @Override

    public Fragment getItem(int position) {

        switch (position)
        {
            case 0:
                GroupChatFragment requistsfregment=new GroupChatFragment();
                return requistsfregment;
            case 1:
                ChatsFragment chatsFragment=new ChatsFragment();
                return chatsFragment;
            case 2:
                FreindsFragment freindsFragment=new FreindsFragment();
                return freindsFragment;
            default:
                return null;
        }

    }
    public CharSequence getPageTitle(int position)
    {
        switch (position )
        {
            case 0:
                return "CHATS";
            case 1:
                return "Friends";

            case 2:
                return "Group Chats";
            default:
                return null;


        }
    }

    @Override
    public int getCount() {
        return 3;
    }
}


